*PADS-LIBRARY-SCH-DECALS-V9*

PTVS5V0S1UTR_115              32000 32000 100 10 100 10 4 5 0 2 8
TIMESTAMP 2019.06.25.13.25.14
"Default Font"
"Default Font"
400   350   0 8 100 10 "Default Font"
REF-DES
400   250   0 8 100 10 "Default Font"
PART-TYPE
400   -200  0 0 100 10 "Default Font"
*
400   -300  0 0 100 10 "Default Font"
*
CLOSED 4 10 0 -1
200   0    
400   100  
400   -100 
200   0    
OPEN   2 10 0 -1
200   100  
200   -100 
OPEN   2 10 0 -1
100   0    
200   0    
OPEN   2 10 0 -1
500   0    
400   0    
OPEN   2 10 0 -1
200   -100 
260   -100 
T0     0     0 0 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T600   0     0 2 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0

*END*
